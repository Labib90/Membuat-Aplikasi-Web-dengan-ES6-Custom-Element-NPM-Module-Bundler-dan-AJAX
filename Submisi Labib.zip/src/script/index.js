import "./script";

console.log();